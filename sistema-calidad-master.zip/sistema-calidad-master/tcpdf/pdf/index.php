<?php

echo "<META HTTP-EQUIV='Refresh' CONTENT='1; URL=ventas.php'/> ";
