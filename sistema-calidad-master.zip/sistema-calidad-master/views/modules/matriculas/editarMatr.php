<?php require 'views/modules/matriculas/matriculas.php';?>
<?php require 'views/modules/modals/editarMatr.php';
