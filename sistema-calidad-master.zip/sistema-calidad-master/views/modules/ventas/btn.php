<input type="submit" name="enviarDetalles" id="enviar"  class="btn btn-block btn-danger" value="Guardar orden">
 <input type="submit" name="enviarCancelar" id="enviarCancelar" data-toggle="modal" data-target="#cancelarVenta" style="margin-bottom: 7px" class="btn btn-block btn-primary" value="Cancelar orden">
<input type="hidden" name="idAdmin" value="<?php echo $_SESSION['idAdmin'] ?>">