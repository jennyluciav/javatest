<?php require 'views/modules/productos/productos.php';?>
<?php require 'views/modules/modals/editarProd.php';
