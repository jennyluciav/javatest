<div aria-hidden="true" aria-labelledby="exampleModalLabel" class="modal fade" id="cancelarVenta" role="dialog" tabindex="-1">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <p>Alerta</p>
            </div>
            <div class="modal-body">
                <div class="alert alert-warning" role="alert">
                    <p>Venta cancelada</p>
                </div>
            </div>
            <div class="modal-footer">
               <button type="button" class="btn btn-outline-danger" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
