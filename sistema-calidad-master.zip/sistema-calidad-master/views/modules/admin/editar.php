<?php require 'views/modules/modals/editarAdmin.php';?>
<?php require 'views/modules/admin/config.php';
