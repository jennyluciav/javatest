<?php require 'views/modules/modals/verCliente.php';
require 'views/modules/clientes/clientes.php';
