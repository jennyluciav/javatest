<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>La Roka GYM - Gestor</title>
  <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
  <link rel="stylesheet" type="text/css" href="views/bootstrap/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="views/bootstrap/css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="views/bootstrap/dataTables/css/dataTables.bootstrap4.css">
  <link rel="stylesheet" type="text/css" href="views/bootstrap/chosen/chosen.css">
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" type="text/css" href="views/bootstrap/css/style.css">
  <script src="views/bootstrap/dataTables/js/jquery.js"></script>
  <script src="views/bootstrap/chosen/chosen.jquery.js"></script>
  <script src="views/bootstrap/js/tether.min.js"></script>
  <script src="views/bootstrap/js/jquery.calidad-validator.js"></script>
  <script src="views/bootstrap/dataTables/js/jquery.dataTables.js"></script>
  <script src="views/bootstrap/dataTables/js/dataTables.bootstrap4.js"></script>
  <script src="views/bootstrap/js/jquery-ui.min.js"></script>
  <script src="views/bootstrap/js/jquery.PrintArea.js"></script>
  <script src="views/bootstrap/js/bootstrap.min.js"></script>
</head>
<body>